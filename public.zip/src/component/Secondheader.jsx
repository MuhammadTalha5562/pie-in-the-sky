import React from 'react'
import './css/secondheader.css';
const Secondheader = () => {
  return (
   <header className='style_header'>
<div className='div_Style'>
<i class="styless fa-solid fa-location-dot"></i>
</div>
   <div>
    <h3 className='Style_Name'>Welcome,</h3>
   </div>
   </header>
  )
}

export default Secondheader