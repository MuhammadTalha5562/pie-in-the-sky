import './App.css';
import Header from './component/Header';
import Secondheader from './component/Secondheader';
function App() {
  return (
    <div className="App">
     <Header/>
    <Secondheader/>
    </div>
  );
}

export default App;
